# FastAPI User CRUD UI

This project adds a simple Tailwind CSS + JavaScript frontend to your FastAPI CRUD backend.

## Folder structure

```text
fastapi_user_ui/
├── main.py
├── database.py
├── models.py
├── schemas.py
├── crud.py
├── requirements.txt
├── templates/
│   └── index.html
└── static/
    ├── css/
    │   └── style.css
    └── js/
        └── app.js
```

## Run the app

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Open your browser:

```text
http://127.0.0.1:8000
```

API docs:

```text
http://127.0.0.1:8000/docs
```

## Notes

- The page uses Tailwind CSS CDN for quick development.
- The JavaScript connects to:
  - `GET /users/`
  - `POST /users/`
  - `PUT /users/{user_id}`
  - `DELETE /users/{user_id}`
- A backward-compatible route `PUT /user/{user_id}` is also included because your original backend used this route.
