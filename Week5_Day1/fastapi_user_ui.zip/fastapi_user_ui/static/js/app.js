const API_BASE_URL = "";

const userForm = document.getElementById("userForm");
const userIdInput = document.getElementById("userId");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const formTitle = document.getElementById("formTitle");
const submitBtn = document.getElementById("submitBtn");
const cancelBtn = document.getElementById("cancelBtn");
const refreshBtn = document.getElementById("refreshBtn");
const messageBox = document.getElementById("message");
const usersTableBody = document.getElementById("usersTableBody");
const searchInput = document.getElementById("searchInput");

let users = [];

function showMessage(text, type = "success") {
  messageBox.textContent = text;
  messageBox.className = "mt-5 rounded-2xl px-4 py-3 text-sm fade-in";

  if (type === "success") {
    messageBox.classList.add("bg-green-50", "text-green-700", "border", "border-green-100");
  } else {
    messageBox.classList.add("bg-red-50", "text-red-700", "border", "border-red-100");
  }

  messageBox.classList.remove("hidden");

  setTimeout(() => {
    messageBox.classList.add("hidden");
  }, 3000);
}

function resetForm() {
  userIdInput.value = "";
  nameInput.value = "";
  emailInput.value = "";
  formTitle.textContent = "Add New User";
  submitBtn.textContent = "Save User";
  cancelBtn.classList.add("hidden");
}

function renderUsers(userList) {
  if (!userList.length) {
    usersTableBody.innerHTML = `
      <tr>
        <td colspan="4" class="px-4 py-8 text-center text-sm text-slate-500">
          No users found.
        </td>
      </tr>
    `;
    return;
  }

  usersTableBody.innerHTML = userList
    .map(
      (user) => `
        <tr class="table-row-hover fade-in">
          <td class="whitespace-nowrap px-4 py-4 text-sm font-medium text-slate-700">${user.id}</td>
          <td class="whitespace-nowrap px-4 py-4 text-sm text-slate-900">${escapeHtml(user.name)}</td>
          <td class="whitespace-nowrap px-4 py-4 text-sm text-slate-600">${escapeHtml(user.email)}</td>
          <td class="whitespace-nowrap px-4 py-4 text-right text-sm">
            <button
              onclick="editUser(${user.id})"
              class="mr-2 rounded-xl border border-slate-200 px-3 py-2 font-semibold text-slate-700 transition hover:bg-slate-50"
            >
              Edit
            </button>
            <button
              onclick="deleteUser(${user.id})"
              class="rounded-xl bg-red-600 px-3 py-2 font-semibold text-white transition hover:bg-red-700"
            >
              Delete
            </button>
          </td>
        </tr>
      `
    )
    .join("");
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

async function loadUsers() {
  usersTableBody.innerHTML = `
    <tr>
      <td colspan="4" class="px-4 py-8 text-center text-sm text-slate-500">
        Loading users...
      </td>
    </tr>
  `;

  try {
    const response = await fetch(`${API_BASE_URL}/users/`);

    if (!response.ok) {
      throw new Error("Failed to load users");
    }

    users = await response.json();
    renderUsers(users);
  } catch (error) {
    renderUsers([]);
    showMessage(error.message, "error");
  }
}

async function createUser(payload) {
  const response = await fetch(`${API_BASE_URL}/users/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    throw new Error("Failed to create user");
  }

  return response.json();
}

async function updateUser(id, payload) {
  const response = await fetch(`${API_BASE_URL}/users/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    throw new Error("Failed to update user");
  }

  return response.json();
}

function editUser(id) {
  const user = users.find((item) => item.id === id);

  if (!user) {
    showMessage("User not found", "error");
    return;
  }

  userIdInput.value = user.id;
  nameInput.value = user.name;
  emailInput.value = user.email;
  formTitle.textContent = "Edit User";
  submitBtn.textContent = "Update User";
  cancelBtn.classList.remove("hidden");
  nameInput.focus();
}

async function deleteUser(id) {
  const confirmed = confirm("Are you sure you want to delete this user?");

  if (!confirmed) return;

  try {
    const response = await fetch(`${API_BASE_URL}/users/${id}`, {
      method: "DELETE"
    });

    if (!response.ok) {
      throw new Error("Failed to delete user");
    }

    showMessage("User deleted successfully");
    await loadUsers();
  } catch (error) {
    showMessage(error.message, "error");
  }
}

userForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const id = userIdInput.value;
  const payload = {
    name: nameInput.value.trim(),
    email: emailInput.value.trim()
  };

  if (!payload.name || !payload.email) {
    showMessage("Please fill in all fields", "error");
    return;
  }

  try {
    if (id) {
      await updateUser(id, payload);
      showMessage("User updated successfully");
    } else {
      await createUser(payload);
      showMessage("User created successfully");
    }

    resetForm();
    await loadUsers();
  } catch (error) {
    showMessage(error.message, "error");
  }
});

cancelBtn.addEventListener("click", resetForm);
refreshBtn.addEventListener("click", loadUsers);

searchInput.addEventListener("input", (event) => {
  const keyword = event.target.value.toLowerCase().trim();

  const filteredUsers = users.filter((user) => {
    return (
      user.name.toLowerCase().includes(keyword) ||
      user.email.toLowerCase().includes(keyword)
    );
  });

  renderUsers(filteredUsers);
});

loadUsers();
